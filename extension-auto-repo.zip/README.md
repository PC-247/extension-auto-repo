# Extension Auto Repo
This repository automatically updates extension indexes every 12 hours.
